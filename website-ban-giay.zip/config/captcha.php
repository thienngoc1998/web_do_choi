<?php
return [
    'recaptcha_key'    => env('NOCAPTCHA_SITEKEY', '6LfC9-IUAAAAAMUzDUoTgOCIO8nIXQ3u6V8qOr0q'),
    'recaptcha_secret' => env('6LfC9-IUAAAAAAF5soq_A-OXSM3XeeaK_DOweLo5', '6LfC9-IUAAAAAAF5soq_A-OXSM3XeeaK_DOweLo5')
];
