<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Static extends Model
{
    protected $table = 'statics';
    protected $guarded = [''];
}
